package Inventario.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.UUID;

import Inventario.app.clases.item;
import Inventario.app.clases.registrouser;
import Inventario.app.clases.usuario;

public class MainActivity extends AppCompatActivity {
    EditText email, password;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email= findViewById(R.id.txt_nombre);
        password=findViewById(R.id.txt_contraseña);

        FirebaseAnalytics analytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString("message","Integracion de firebase completa");
        analytics.logEvent("InitScreen", bundle);
        setup();

    }

    private void setup() {
        setTitle("Autenticación");

        Button myButton = findViewById(R.id.Registrar);
        Button myButton2 = findViewById(R.id.Iniciar);

        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainMenuIntent = new Intent(MainActivity.this, registrouser.class);
                startActivity(mainMenuIntent);}});

        myButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailUser = email.getText().toString().trim();
                String passUser = password.getText().toString().trim();


                {
                    if (emailUser.isEmpty() || passUser.isEmpty()){
                        Toast.makeText(MainActivity.this, "Complete los datos", Toast.LENGTH_SHORT).show();

                    } else {
                        FirebaseAuth.getInstance().signInWithEmailAndPassword(emailUser,passUser).addOnCompleteListener(task -> {
                                    if (task.isSuccessful()){
                                        String email = task.getResult().getUser().getEmail();
                                        showHome(email != null ? email:"", MainActivityMenu.ProviderType.BASIC);

                                    }else {
                                        showAlert();
                                    }
                                }

                        );
                    }
                }}});



    }

    private void showAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Error");
        builder.setMessage(("Se ha producido un error autenticando al usuario"));
        AlertDialog dialog = builder.create();
        dialog.show();

    }
    private void showHome(String email, MainActivityMenu.ProviderType provider){
        Intent homeIntent = new Intent(this, MainActivityMenu.class);
        homeIntent.putExtra("email",email);
        homeIntent.putExtra("provider",provider.name());

        startActivity(homeIntent);

    }



}