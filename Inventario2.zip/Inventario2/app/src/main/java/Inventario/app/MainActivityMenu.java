package Inventario.app;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import Inventario.app.clases.usuario;

public class MainActivityMenu extends AppCompatActivity {
    Button boton1,boton2,boton3,boton4;

    FirebaseDatabase db;
    DatabaseReference dr;
    EditText email, password;
    public enum ProviderType {
        BASIC
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        email= findViewById(R.id.txt_nombre);
        password=findViewById(R.id.txt_contraseña);

        Bundle datos=getIntent().getExtras();
        String email = datos != null ? datos.getString("email", ""): "";
        String provider = datos != null ? datos.getString("provider",""): "";
        setup(email,provider);



        conectar();

        boton1=findViewById(R.id.Menufactura);
        boton2=findViewById(R.id.Menuinventario);
        boton3=findViewById(R.id.Menuopciones);
        boton4=findViewById(R.id.LogOut);
        boton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                onBackPressed();
            }
        });
        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivityMenu.this,Facturacion.class);
                intent.putExtras(datos);
                startActivity(intent);
            }
        });
        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivityMenu.this,InterfazInventario.class);
                intent.putExtras(datos);
                startActivity(intent);
            }
        });
        boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivityMenu.this,Opciones.class);
                intent.putExtras(datos);
                startActivity(intent);
            }
        });

    }
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    private void setup(String email, String provider) {
        setTitle("Inicio");
        TextView emailtextView = findViewById(R.id.emailtextView);
        TextView providertextView = findViewById(R.id.providertextView);
        Button logoutButton = findViewById(R.id.LogOut);

        emailtextView.setText(email);
        providertextView.setText(provider);

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                onBackPressed();
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    private void conectar() {
        FirebaseApp.initializeApp(this);
        db= FirebaseDatabase.getInstance();
        dr=db.getReference();
    }
}