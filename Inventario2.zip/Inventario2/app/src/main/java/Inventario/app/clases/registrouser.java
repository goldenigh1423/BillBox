package Inventario.app.clases;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;

import Inventario.app.InterfazInventario;
import Inventario.app.MainActivity;
import Inventario.app.MainActivityMenu;
import Inventario.app.R;

public class registrouser extends AppCompatActivity {

    EditText email, password;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrouser);
        email = findViewById(R.id.txt_nomr);
        password = findViewById(R.id.txt_conr);
        FirebaseAnalytics analytics = FirebaseAnalytics.getInstance(this);
        Bundle datos = new Bundle();
        datos.putString("nombre", "nombre_usuario");
        datos.putString("contraseña", "contraseña_usuario");
        datos.putString("message","Integracion de firebase completa");
        analytics.logEvent("InitScreen", datos);
        setup();
    }

    private void setup() {
        setTitle("Autenticacion");
        Button mybutton = findViewById(R.id.Registrarr);
        Button mybutton2 = findViewById(R.id.Volverr);

        mybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String emailUser = email.getText().toString().trim();
                String passUser = password.getText().toString().trim();
                {
                    if (emailUser.isEmpty() || passUser.isEmpty()){
                        Toast.makeText(registrouser.this, "Complete los datos", Toast.LENGTH_SHORT).show();

                    } else {
                        FirebaseAuth.getInstance().createUserWithEmailAndPassword(emailUser,passUser).addOnCompleteListener(task -> {
                                    if (task.isSuccessful()){
                                        String email = task.getResult().getUser().getEmail();
                                        showHome(email != null ? email:"", MainActivityMenu.ProviderType.BASIC);

                                    }else {
                                        showAlert();
                                    }
                                }

                        );
                    }
                }}});
        mybutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainMenuIntent = new Intent(registrouser.this, MainActivity.class);
                startActivity(mainMenuIntent);

            }});


    }
    private void showAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Error");
        builder.setMessage(("Se ha producido un error autenticando al usuario"));
        AlertDialog dialog = builder.create();
        dialog.show();

    }

    private void showHome(String email, MainActivityMenu.ProviderType provider){
        Intent homeIntent = new Intent(this, MainActivityMenu.class);
        homeIntent.putExtra("email",email);
        homeIntent.putExtra("provider",provider.name());

        startActivity(homeIntent);

    }
}