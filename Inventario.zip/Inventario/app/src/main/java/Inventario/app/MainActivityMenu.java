package Inventario.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import Inventario.app.clases.usuario;

public class MainActivityMenu extends AppCompatActivity {
    Button boton1,boton2,boton3,boton4;

    FirebaseDatabase db;
    DatabaseReference dr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        Bundle datos=getIntent().getExtras();
        usuario u=new usuario(datos.getStringArray("key")[0],datos.getStringArray("key")[1]);
        conectar();

        boton1=findViewById(R.id.Menufactura);
        boton2=findViewById(R.id.Menuinventario);
        boton3=findViewById(R.id.Menuopciones);
        boton4=findViewById(R.id.LogOut);
        boton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivityMenu.this, u.getNombre()+" "+u.getContraseña(), Toast.LENGTH_LONG).show();
            }
        });
        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivityMenu.this,Facturacion.class);
                intent.putExtras(datos);
                startActivity(intent);
            }
        });
        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivityMenu.this,InterfazInventario.class);
                intent.putExtras(datos);
                startActivity(intent);
            }
        });
        boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivityMenu.this,Opciones.class);
                intent.putExtras(datos);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    private void conectar() {
        FirebaseApp.initializeApp(this);
        db= FirebaseDatabase.getInstance();
        dr=db.getReference();
    }
}