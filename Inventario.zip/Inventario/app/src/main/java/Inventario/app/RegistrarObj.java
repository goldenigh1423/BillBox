package Inventario.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import Inventario.app.clases.item;
import Inventario.app.clases.usuario;

public class RegistrarObj extends AppCompatActivity {
    FirebaseDatabase db;
    DatabaseReference dr;

    EditText nombre,referencia,proveedor,cantidad,costo,precio;
    Button registrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_obj);

        Bundle datos=getIntent().getExtras();
        usuario u=new usuario(datos.getStringArray("key")[0],datos.getStringArray("key")[1]);
        conectar();

        nombre=findViewById(R.id.registrarobjnombre);
        referencia=findViewById(R.id.registrarobjref);
        proveedor=findViewById(R.id.registrarobjproov);
        cantidad=findViewById(R.id.registrarobjcantidad);
        costo=findViewById(R.id.registrarobjcosto);
        precio=findViewById(R.id.registrarobjprecio);
        registrar=findViewById(R.id.registrarobjboton);
        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nombre.getText().toString().equals("")||referencia.getText().toString().equals("")||proveedor.getText().toString().equals("")||cantidad.getText().toString().equals("")||precio.getText().toString().equals("")||costo.getText().toString().equals("")) {
                    validar();
                }else{
                    item item=new item(Integer.parseInt(cantidad.getText().toString()),Integer.parseInt(costo.getText().toString()),nombre.getText().toString(),Integer.parseInt(precio.getText().toString()),proveedor.getText().toString(),referencia.getText().toString());
                    nombre.setText(null);
                    referencia.setText(null);
                    proveedor.setText(null);
                    cantidad.setText(null);
                    costo.setText(null);
                    precio.setText(null);
                    dr.child("usuario").child(u.getNombre()).child("inventario").child(item.getReferencia()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()){
                                Toast.makeText(RegistrarObj.this, "Este item ya existe", Toast.LENGTH_LONG).show();
                            }else{
                                dr.child("usuario").child(u.getNombre()).child("inventario").child(item.getReferencia()).setValue(item);
                                Toast.makeText(RegistrarObj.this, "Ha sido registrado con exito", Toast.LENGTH_LONG).show();
                                Intent intent=new Intent(RegistrarObj.this,InterfazInventario.class);
                                intent.putExtras(datos);
                                startActivity(intent);
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(RegistrarObj.this, "Ha aparecido un error, intentalo mas tarde", Toast.LENGTH_LONG).show();
                        }
                    });

                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    private void conectar() {
        FirebaseApp.initializeApp(this);
        db= FirebaseDatabase.getInstance();
        dr=db.getReference();
    }

    private void validar() {
        if(nombre.getText().toString().equals("")){
            nombre.setError("requerido");
        }else if(referencia.getText().toString().equals("")){
            referencia.setError("requerido");
        }else if(proveedor.getText().toString().equals("")){
            proveedor.setError("requerido");
        }else if(cantidad.getText().toString().equals("")){
            cantidad.setError("requerido");
        }else if(costo.getText().toString().equals("")){
            costo.setError("requerido");
        }else if(precio.getText().toString().equals("")){
            precio.setError("requerido");
        }
    }
}