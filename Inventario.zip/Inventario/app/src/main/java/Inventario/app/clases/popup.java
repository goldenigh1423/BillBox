package Inventario.app.clases;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;

import Inventario.app.R;

public class popup {

    // Método para mostrar la ventana emergente
    public static void popup(final Context context, View view,Bitmap bm) {
        // Inflar el diseño de la ventana emergente
        View popupView = LayoutInflater.from(context).inflate(R.layout.popup, null);

        // Crear la ventana emergente
        final PopupWindow popupWindow = new PopupWindow(
                popupView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                true);

        // Configurar la ventana emergente
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setOutsideTouchable(true);

        // Obtener la referencia a la imagen y al botón en la ventana emergente
        final ImageView imgPopup = popupView.findViewById(R.id.imgPopup);
        Button btnDownload = popupView.findViewById(R.id.btnDownload);

        // Asignar la imagen a la ImageView
        imgPopup.setImageBitmap(bm);

        // Configurar el botón de descarga
        btnDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Agregar aquí la lógica de descarga de la imagen
                // Por ejemplo, puedes usar un Intent para descargar la imagen
                // o realizar alguna otra acción según tus necesidades.
            }
        });

        // Mostrar la ventana emergente en la ubicación específica
        popupWindow.showAtLocation(view, 0, 50, 50);
    }
}

