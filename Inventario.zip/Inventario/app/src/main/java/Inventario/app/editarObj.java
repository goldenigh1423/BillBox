package Inventario.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Inventario.app.clases.QRmanager;
import Inventario.app.clases.item;

public class editarObj extends AppCompatActivity {
    FirebaseDatabase db;
    DatabaseReference dr;
    FirebaseAuth auth;
    FirebaseUser user;

    EditText nombre,referencia,proveedor,cantidad,costo,precio;
    Button registrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_obj);

        conectar();

        nombre=findViewById(R.id.registrarobjnombre);
        referencia=findViewById(R.id.registrarobjref);
        proveedor=findViewById(R.id.registrarobjproov);
        cantidad=findViewById(R.id.registrarobjcantidad);
        costo=findViewById(R.id.registrarobjcosto);
        precio=findViewById(R.id.registrarobjprecio);
        registrar=findViewById(R.id.registrarobjboton);

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validar()) {
                    item item=new item(Integer.parseInt(cantidad.getText().toString()),Integer.parseInt(costo.getText().toString()),nombre.getText().toString(),Integer.parseInt(precio.getText().toString()),proveedor.getText().toString(),referencia.getText().toString());
                    borrar();
                    dr.child("usuario").child(user.getUid()).child("inventario").child(item.getReferencia()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()){
                                dr.child("usuario").child(user.getUid()).child("inventario").child(item.getReferencia()).setValue(item);
                                Toast.makeText(editarObj.this, "Se ha editado", Toast.LENGTH_LONG).show();
                                Intent intent=new Intent(editarObj.this,InterfazInventario.class);
                                startActivity(intent);

                            }else{
                                Toast.makeText(editarObj.this, "Este item no existe", Toast.LENGTH_LONG).show();
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(editarObj.this, "Ha aparecido un error, intentalo mas tarde", Toast.LENGTH_LONG).show();
                        }
                    });

                }
            }
        });
    }

    private void rellenar() {
        dr.child("usuario").child(user.getUid()).child("inventario").child(referencia.getText().toString()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    nombre.setText(snapshot.child("nombre").getValue(String.class));
                    proveedor.setText(snapshot.child("proveedor").getValue(String.class));
                    cantidad.setText(snapshot.child("catidad").getValue().toString());
                    costo.setText(snapshot.child("costo").getValue().toString());
                    precio.setText(snapshot.child("precio").getValue().toString());
                    referencia.setEnabled(false);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private boolean validar() {
        if(nombre.getText().toString().equals("")){
            nombre.setError("requerido");
            return false;
        }else if(referencia.getText().toString().equals("")){
            referencia.setError("requerido");
            return false;
        }else if(proveedor.getText().toString().equals("")){
            proveedor.setError("requerido");
            return false;
        }else if(cantidad.getText().toString().equals("")){
            cantidad.setError("requerido");
            return false;
        }else if(costo.getText().toString().equals("")){
            costo.setError("requerido");
            return false;
        }else if(precio.getText().toString().equals("")){
            precio.setError("requerido");
            return false;
        }
        return true;
    }
    private void borrar(){
        nombre.setText(null);
        referencia.setText(null);
        proveedor.setText(null);
        cantidad.setText(null);
        costo.setText(null);
        precio.setText(null);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.icon_add){
            QRmanager.escaner(editarObj.this);
        }
        return true;
    }

    protected void onActivityResult(int requestCode, int resultCode,Intent data) {
        IntentResult res = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (res != null) {
            if (res.getContents() != null) {
                Pattern pattern = Pattern.compile("_producto:(\\w+)_nombre:(\\w+)_referencia:(\\w+)");
                Matcher matcher = pattern.matcher(res.getContents());
                if (matcher.find() && matcher.group(1).equals(user.getUid())) {
                    referencia.setText(matcher.group(3));
                    rellenar();
                } else {
                    Toast.makeText(editarObj.this, "No se ha podido leer el qr", Toast.LENGTH_LONG).show();
                }
            }else{
                Toast.makeText(editarObj.this, "No se ha podido leer el qr", Toast.LENGTH_LONG).show();
            }
        }else{
            Toast.makeText(editarObj.this, "No se ha podido leer el qr", Toast.LENGTH_LONG).show();
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void conectar() {
        FirebaseApp.initializeApp(this);
        db= FirebaseDatabase.getInstance();
        dr=db.getReference();
        auth = FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
    }
}
