package Inventario.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.UUID;

import Inventario.app.clases.item;
import Inventario.app.clases.usuario;

public class MainActivity extends AppCompatActivity {
    Button iniciar,registrar;
    EditText nombre,contraseña;

    FirebaseDatabase db;
    DatabaseReference dr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        registrar=findViewById(R.id.Registrar);
        iniciar=findViewById(R.id.Iniciar);
        nombre=findViewById(R.id.txt_nombre);
        contraseña=findViewById(R.id.txt_contraseña);
        conectar();
        iniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if(nombre.getText().toString().equals("")||contraseña.getText().toString().equals("")) {
                    validar();
                }else{
                    usuario u=new usuario(nombre.getText().toString(),contraseña.getText().toString());
                    nombre.setText(null);
                    contraseña.setText(null);
                    dr.child("usuario").child(u.getNombre()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()){
                                if(snapshot.child("contraseña").getValue(String.class).equals(u.getContraseña())){
                                    Toast.makeText(MainActivity.this, "Iniciando", Toast.LENGTH_LONG).show();
                                    String[] k={u.getNombre(),u.getContraseña()};
                                    Bundle enviar=new Bundle();
                                    enviar.putStringArray("key",k);
                                    Intent intent=new Intent(MainActivity.this,MainActivityMenu.class);
                                    intent.putExtras(enviar);
                                    startActivity(intent);
                                }else{
                                    Toast.makeText(MainActivity.this, "Contraseña equivocada", Toast.LENGTH_LONG).show();
                                }

                            }else{
                                Toast.makeText(MainActivity.this, "Este usuario no existe", Toast.LENGTH_LONG).show();
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(MainActivity.this, "Ha aparecido un error, intentalo mas tarde", Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nombre.getText().toString().equals("")||contraseña.getText().toString().equals("")) {
                    validar();
                }else{
                    usuario u=new usuario(nombre.getText().toString(),contraseña.getText().toString());
                    nombre.setText(null);
                    contraseña.setText(null);
                    dr.child("usuario").child(u.getNombre()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()){
                                Toast.makeText(MainActivity.this, "Este usuario ya existe", Toast.LENGTH_LONG).show();
                            }else{
                                dr.child("usuario").child(u.getNombre()).setValue(u);
                                Toast.makeText(MainActivity.this, "Ha sido registrado con exito", Toast.LENGTH_LONG).show();
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(MainActivity.this, "Ha aparecido un error, intentalo mas tarde", Toast.LENGTH_LONG).show();
                        }
                    });

                }
            }
        });
    }

    private void borrar() {
        nombre.setText("");
        contraseña.setText("");
    }

    private void validar() {
        if(nombre.getText().toString().equals("")){
            nombre.setError("requerido");
        }else if(contraseña.getText().toString().equals("")){
            contraseña.setError("requerido");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    private void conectar() {
        FirebaseApp.initializeApp(this);
        db=FirebaseDatabase.getInstance();
        dr=db.getReference();
    }
}