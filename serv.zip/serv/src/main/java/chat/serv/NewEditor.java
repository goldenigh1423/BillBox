package chat.serv;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import org.java_websocket.client.WebSocketClient;

public class NewEditor {
    public static void main(String[] args) throws MalformedURLException, IOException, URISyntaxException {
                
        URI uri = new URI("ws", null, "192.168.68.111", 8554, null, null, null);
        WebSocketClient cl=new cliente(uri);
        cl.connect();
    }
}
