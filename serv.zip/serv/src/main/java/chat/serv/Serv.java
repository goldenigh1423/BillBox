package chat.serv;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.URISyntaxException;
import org.java_websocket.server.WebSocketServer;

public class Serv {

    public static void main(String[] args) throws IOException, URISyntaxException {
        conectar.conectar();
        int puerto=buscar();
        String host="192.168.68.111";
        conectar.setServer(host, puerto);
        WebSocketServer ser=new servidor(new InetSocketAddress(host,8554));
        ser.run();
    }
    
    private static int buscar() throws IOException{
        int puerto=0;
        for(int i=1;i<65000;i++){
            try{
                ServerSocket s=new ServerSocket(i);
                s.close();
                puerto=i;
                break;
            }catch(IOException e){
            }
        }
        return puerto;
    }
}
