package chat.serv;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class conectar {
    public static void conectar() throws FileNotFoundException, IOException{
        FileInputStream serviceAccount =new FileInputStream("server.json");

        FirebaseOptions options = new FirebaseOptions.Builder()
            .setCredentials(GoogleCredentials.fromStream(serviceAccount))
            .setDatabaseUrl("https://inventario-38a1d-default-rtdb.firebaseio.com")
            .build();

        FirebaseApp.initializeApp(options);
    }
    
    public static void setServer(String host, int puerto){
        DatabaseReference ref=FirebaseDatabase.getInstance().getReference().child("server");
        Map<String,Object> map=new HashMap<>();
        map.put("host", host);
        map.put("puerto", puerto);
        ref.setValueAsync(map);
    }
}

