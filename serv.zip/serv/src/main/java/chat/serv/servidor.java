package chat.serv;

import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Queue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

public class servidor extends WebSocketServer {
    protected HashMap<String,WebSocket> clientes;
    protected HashMap<String,Queue<String>> espera;
    protected HashMap<String,String> nombres;
    
    public servidor(InetSocketAddress adre) throws UnknownHostException{
        super(adre);
        espera=new HashMap<>();
        clientes=new HashMap<>();
    }

    @Override
    public void onOpen(WebSocket ws, ClientHandshake ch) {
        System.out.println("Usuario se ha conectado");
    }

    @Override
    public void onClose(WebSocket ws, int i, String string, boolean bln) {
        System.out.println("Usuario se ha desconectado");
    }

    @Override
    public void onMessage(WebSocket ws, String sms) {
        Matcher mat=act(sms);
        String act=mat.group(1);
        String val=mat.group(3);
        String dest=mat.group(2);
        switch (act) {
            case "Mensaje" -> mensaje(dest,val);
            case "RegObj" -> regobj(val);
            case "SetUID" -> reguser(val,ws);
            default -> throw new AssertionError();
        }
    }

    @Override
    public void onError(WebSocket ws, Exception excptn) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void onStart() {
        System.out.println("servidor conectado: ");
    }

    private Matcher act(String sms) {
        Pattern pattern = Pattern.compile("_acto:(\\w+)_destino:(\\w+)_valor:(\\w+)");
        Matcher matcher = pattern.matcher(sms);
        return matcher;
    }

    private void regobj(String val) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void reguser(String val, WebSocket ws) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void mensaje(String dest, String val) {
        
    }
}
