package chat.serv;

import java.net.URI;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

public class cliente extends WebSocketClient {

    public cliente(URI serverUri) {
        super(serverUri);
    }


    @Override
    public void onOpen(ServerHandshake sh) {
        
    }

    @Override
    public void onMessage(String string) {}

    @Override
    public void onClose(int i, String string, boolean bln) {}

    @Override
    public void onError(Exception excptn) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
